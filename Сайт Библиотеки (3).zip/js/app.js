// ============================================================
// ACADEMIC SALON — Dark Couture · Interactive Layer
// ============================================================

(function(){
  'use strict';

  // ---------- Bootstrap: curtain ----------
  window.addEventListener('load', () => {
    setTimeout(() => document.body.classList.add('ready'), 200);
  });
  // Fallback на случай если load уже произошёл
  if (document.readyState === 'complete'){
    setTimeout(() => document.body.classList.add('ready'), 200);
  }

  const isWeak = navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4;
  const prefersReduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // ---------- NAV: scroll + progress + active ----------
  const nav = document.querySelector('.nav');
  const burger = document.querySelector('.nav-burger');
  const sections = document.querySelectorAll('section[id]');

  function onScroll(){
    const y = window.scrollY;
    if (y > 20) nav.classList.add('scrolled'); else nav.classList.remove('scrolled');

    const h = document.documentElement.scrollHeight - window.innerHeight;
    const p = h > 0 ? (y / h) * 100 : 0;
    document.documentElement.style.setProperty('--p', p.toFixed(2) + '%');

    // Active section
    let current = '';
    sections.forEach(s => {
      const rect = s.getBoundingClientRect();
      if (rect.top <= 160 && rect.bottom > 160) current = s.id;
    });
    document.querySelectorAll('.nav-links a').forEach(a => {
      const href = a.getAttribute('href') || '';
      a.classList.toggle('is-active', href === '#' + current);
    });

    // Параллакс
    if (!prefersReduce){
      document.querySelectorAll('[data-parallax]').forEach(el => {
        const rect = el.getBoundingClientRect();
        const inView = rect.top < window.innerHeight && rect.bottom > 0;
        if (!inView) return;
        const speed = parseFloat(el.dataset.parallax) || 0.2;
        const centerOffset = (rect.top + rect.height / 2) - window.innerHeight / 2;
        const shift = -centerOffset * speed;
        el.style.transform = `translate3d(0, ${shift.toFixed(1)}px, 0)`;
      });
    }
  }
  let rafId;
  window.addEventListener('scroll', () => {
    if (rafId) return;
    rafId = requestAnimationFrame(() => { onScroll(); rafId = null; });
  }, { passive: true });
  onScroll();

  if (burger){
    burger.addEventListener('click', () => nav.classList.toggle('open'));
  }
  document.querySelectorAll('.nav-drawer a, .nav-links a').forEach(a => {
    a.addEventListener('click', () => nav.classList.remove('open'));
  });

  // ---------- Reveal on scroll ----------
  const io = ('IntersectionObserver' in window) ? new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting){
        e.target.classList.add('in');
        io.unobserve(e.target);
      }
    });
  }, { threshold: 0.08, rootMargin: '0px 0px -50px 0px' }) : null;
  document.querySelectorAll('[data-reveal]').forEach(el => {
    if (io) io.observe(el); else el.classList.add('in');
  });

  // ---------- CALENDAR — подготовить состояние на основе текущего месяца ----------
  const CAL_MONTHS = [
    'Январь','Февраль','Март','Апрель','Май','Июнь',
    'Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'
  ];

  function buildCalendar(){
    const track = document.querySelector('.calendar-months');
    if (!track) return;
    const now = new Date();
    const curMonth = now.getMonth(); // 0..11

    // Сценарий: декабрь-январь и май-июнь — пик защит; летом — затишье
    // Состояние: free / tight / closed
    // Ближайшие 2 месяца — closed (забронировано), потом 3 — tight, далее — free
    track.innerHTML = '';
    for (let i = 0; i < 12; i++){
      const offset = i;
      const m = (curMonth + offset) % 12;
      let state = 'free';
      let booked = '35%';
      let text = 'свободно';
      let extra = '';
      if (offset === 0) { state = 'closed'; booked = '100%'; text = 'забронировано'; extra = 'полностью'; }
      else if (offset === 1) { state = 'closed'; booked = '94%'; text = 'занято'; extra = '1–2 окна'; }
      else if (offset === 2) { state = 'tight'; booked = '72%'; text = 'мало окон'; extra = '28% свободно'; }
      else if (offset === 3) { state = 'tight'; booked = '55%'; text = 'разумно'; extra = '45% свободно'; }
      else if (offset >= 4 && offset <= 7) { state = 'free'; booked = (25 + offset * 3) + '%'; text = 'открыто'; extra = 'лучшее время'; }
      else { state = 'free'; booked = (35 + offset * 2) + '%'; text = 'открыто'; extra = 'бронь'; }

      // Пиковые месяцы (май-июнь, декабрь) — подтянуть к tight
      const peakPeriods = [4, 5, 11]; // май, июнь, декабрь
      if (peakPeriods.includes(m) && state === 'free'){
        state = 'tight';
        booked = '68%';
        text = 'пик защит';
        extra = 'бронь ранняя';
      }

      const el = document.createElement('button');
      el.className = 'month ' + state;
      el.style.setProperty('--booked', booked);
      el.innerHTML = `
        <div class="month-name">${CAL_MONTHS[m]}</div>
        <div class="month-node"></div>
        <div class="month-stat">
          <b>${text}</b>
          ${extra}
        </div>
        <div class="month-bar"></div>
      `;
      el.addEventListener('click', () => {
        const msg = state === 'closed'
          ? `${CAL_MONTHS[m]} — места заняты. Напишите — обсудим следующий месяц.`
          : state === 'tight'
            ? `${CAL_MONTHS[m]} — осталось немного мест. Напишите, чтобы забронировать.`
            : `${CAL_MONTHS[m]} — окна свободны. Лучшее время для брони.`;
        showToast(msg);
      });
      track.appendChild(el);
    }
  }
  buildCalendar();

  // ---------- FORMULA (калькулятор) ----------
  const PRICING = {
    'essay':        { base: 2500,  perPage: 120, label: 'Самостоятельная',   latin: 'Exercitium',      defaultPages: 12, range: [5, 40],   description: 'Самостоятельная работа, эссе, контрольная. Небольшая форма, быстро.' },
    'referat':      { base: 3500,  perPage: 150, label: 'Реферат',           latin: 'Relatio brevis',  defaultPages: 20, range: [10, 40],  description: 'Реферат на заданную тему, авторский текст, оформление по ГОСТ.' },
    'coursework':   { base: 8500,  perPage: 250, label: 'Курсовая работа',   latin: 'Opus annuum',     defaultPages: 30, range: [20, 50],  description: 'Курсовая: теоретическая и практическая части, 30–50 страниц, выводы по главам.' },
    'practice':     { base: 8000,  perPage: 200, label: 'Отчёт по практике', latin: 'Relatio exercitationis', defaultPages: 25, range: [15, 45], description: 'Отчёт учебной, производственной или преддипломной практики с дневником и приложениями.' },
    'diploma':      { base: 40000, perPage: 450, label: 'Дипломная · ВКР',   latin: 'Opus magnum',     defaultPages: 65, range: [40, 100], description: 'Выпускная квалификационная работа под ключ — от темы до защиты.' },
    'master':       { base: 60000, perPage: 550, label: 'Магистерская',      latin: 'Dissertatio',     defaultPages: 85, range: [60, 130], description: 'Магистерская диссертация с эмпирикой, апробацией, публикациями.' },
    'presentation': { base: 7500,  perPage: 280, label: 'Презентация',       latin: 'Oratio',          defaultPages: 15, range: [8, 30],   description: 'Презентация и речь к защите. Слайды в стиле вашего ВУЗа, речь 7–10 минут.' },
    'article':      { base: 6000,  perPage: 400, label: 'Научная статья',    latin: 'Articulus',       defaultPages: 10, range: [5, 20],   description: 'Статья в журналы ВАК, РИНЦ, студенческие сборники. С подбором журнала.' },
  };
  const URGENCY = {
    'normal': { mult: 1.0,  label: 'Неспешно',    note: '7–14 дней' },
    'brisk':  { mult: 1.25, label: 'Собранно',    note: '3–5 дней' },
    'urgent': { mult: 1.6,  label: 'К утру',      note: '24 часа' },
  };
  const EXTRAS = {
    'antiplag':   { price: 1500, label: 'Антиплагиат ВУЗ до 90%' },
    'speech':     { price: 2500, label: 'Речь на защиту' },
    'slides':     { price: 3500, label: 'Презентация · 15 слайдов' },
  };

  const state = {
    type: 'coursework',
    urgency: 'normal',
    pages: PRICING['coursework'].defaultPages,
    extras: new Set(),
  };

  function money(n){
    return Math.round(n).toLocaleString('ru-RU').replace(/,/g, '\u2009');
  }

  function renderTypes(){
    const wrap = document.querySelector('.formula-types');
    if (!wrap) return;
    wrap.innerHTML = '';
    Object.entries(PRICING).forEach(([k, p]) => {
      const b = document.createElement('button');
      b.className = 'formula-opt' + (k === state.type ? ' is-active' : '');
      b.innerHTML = `<span>${p.label}</span><span class="p">${money(p.base)}</span>`;
      b.onclick = () => {
        state.type = k;
        state.pages = p.defaultPages;
        render();
      };
      wrap.appendChild(b);
    });
  }
  function renderUrgency(){
    const wrap = document.querySelector('.formula-urg');
    if (!wrap) return;
    wrap.innerHTML = '';
    Object.entries(URGENCY).forEach(([k, u]) => {
      const b = document.createElement('button');
      b.className = 'formula-opt' + (k === state.urgency ? ' is-active' : '');
      b.innerHTML = `<span>${u.label}</span><span class="p">${u.note}</span>`;
      b.onclick = () => { state.urgency = k; render(); };
      wrap.appendChild(b);
    });
  }
  function renderExtras(){
    const wrap = document.querySelector('.formula-extras');
    if (!wrap) return;
    wrap.innerHTML = '';
    Object.entries(EXTRAS).forEach(([k, e]) => {
      const b = document.createElement('button');
      const on = state.extras.has(k);
      b.className = 'formula-opt' + (on ? ' is-active' : '');
      b.innerHTML = `<span>${e.label}</span><span class="p">+${money(e.price)}</span>`;
      b.onclick = () => {
        if (state.extras.has(k)) state.extras.delete(k);
        else state.extras.add(k);
        render();
      };
      wrap.appendChild(b);
    });
  }
  function renderSlider(){
    const slider = document.getElementById('formulaPages');
    const val = document.getElementById('formulaPagesVal');
    const bounds = document.getElementById('formulaBounds');
    if (!slider) return;
    const p = PRICING[state.type];
    slider.min = p.range[0];
    slider.max = p.range[1];
    slider.value = state.pages;
    const fill = ((state.pages - p.range[0]) / (p.range[1] - p.range[0])) * 100;
    slider.style.setProperty('--fill', fill + '%');
    if (val) val.innerHTML = state.pages + ' <small>стр.</small>';
    if (bounds) bounds.textContent = `${p.range[0]} — ${p.range[1]} страниц`;
  }
  function renderResult(){
    const p = PRICING[state.type];
    const u = URGENCY[state.urgency];
    let base = p.base + Math.max(0, state.pages - p.defaultPages) * p.perPage;
    base = Math.max(p.base, base);
    const extrasSum = [...state.extras].reduce((s, k) => s + (EXTRAS[k]?.price || 0), 0);
    const subtotal = base + extrasSum;
    const total = subtotal * u.mult;

    const totalEl = document.getElementById('formulaTotal');
    if (totalEl) totalEl.innerHTML = money(total) + '<span class="cur">руб.</span>';

    const brk = document.getElementById('formulaRows');
    if (brk){
      brk.innerHTML = '';
      const rows = [
        { k: `${p.label}, ${state.pages} стр.`, v: money(base) + ' ₽' },
      ];
      [...state.extras].forEach(k => {
        const e = EXTRAS[k];
        if (!e) return;
        rows.push({ k: e.label, v: '+ ' + money(e.price) + ' ₽', sub: true });
      });
      if (u.mult > 1){
        rows.push({ k: `Срочность — ${u.label.toLowerCase()}`, v: '× ' + u.mult, sub: true });
      }
      rows.forEach(r => {
        const el = document.createElement('div');
        el.className = 'receipt-row' + (r.sub ? ' sub' : '');
        el.innerHTML = `<span class="k">${r.k}</span><span class="v">${r.v}</span>`;
        brk.appendChild(el);
      });
    }
  }
  function render(){
    renderTypes();
    renderUrgency();
    renderExtras();
    renderSlider();
    renderResult();
  }

  const pagesInput = document.getElementById('formulaPages');
  if (pagesInput){
    pagesInput.addEventListener('input', e => {
      state.pages = +e.target.value;
      renderSlider();
      renderResult();
    });
  }
  render();

  // ---------- ARCHIVE: filter ----------
  window.ARCHIVE_FILTER = 'all';
  document.querySelectorAll('.archive-filter').forEach(f => {
    f.addEventListener('click', () => {
      document.querySelectorAll('.archive-filter').forEach(x => x.classList.remove('is-active'));
      f.classList.add('is-active');
      window.ARCHIVE_FILTER = f.dataset.type || 'all';
      document.querySelectorAll('.archive-row').forEach(r => {
        const t = r.dataset.type;
        r.style.display = (window.ARCHIVE_FILTER === 'all' || t === window.ARCHIVE_FILTER) ? '' : 'none';
      });
    });
  });

  // ---------- METHOD: tabs ----------
  const mTabs = document.querySelectorAll('.method-tab');
  const mPanels = document.querySelectorAll('.method-panel');
  mTabs.forEach((t, i) => {
    t.addEventListener('click', () => {
      mTabs.forEach(x => x.classList.remove('is-active'));
      mPanels.forEach(x => x.classList.remove('is-active'));
      t.classList.add('is-active');
      if (mPanels[i]) mPanels[i].classList.add('is-active');
    });
    t.addEventListener('mouseenter', () => {
      if (window.innerWidth < 900) return;
      mTabs.forEach(x => x.classList.remove('is-active'));
      mPanels.forEach(x => x.classList.remove('is-active'));
      t.classList.add('is-active');
      if (mPanels[i]) mPanels[i].classList.add('is-active');
    });
  });

  // ---------- MODAL ----------
  const modal = document.getElementById('modal');
  function openModal(prefill){
    if (!modal) return;
    if (prefill){
      const topic = document.getElementById('fTopic');
      if (topic) topic.value = prefill;
    }
    modal.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  function closeModal(){
    if (!modal) return;
    modal.classList.remove('open');
    document.body.style.overflow = '';
  }
  document.querySelectorAll('[data-open-modal]').forEach(el => {
    el.addEventListener('click', e => {
      e.preventDefault();
      openModal(el.dataset.prefill);
    });
  });
  document.querySelectorAll('[data-close-modal]').forEach(el => {
    el.addEventListener('click', closeModal);
  });
  if (modal){
    modal.addEventListener('click', e => { if (e.target === modal) closeModal(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });
  }
  const form = document.getElementById('orderForm');
  if (form){
    form.addEventListener('submit', e => {
      e.preventDefault();
      closeModal();
      showToast('Заявка принята. Отвечаем в течение 15 минут.');
    });
  }

  // Order from formula
  const formulaOrder = document.getElementById('formulaOrder');
  if (formulaOrder){
    formulaOrder.addEventListener('click', e => {
      e.preventDefault();
      const p = PRICING[state.type];
      openModal(`${p.label}, ${state.pages} стр., срочность: ${URGENCY[state.urgency].label.toLowerCase()}`);
    });
  }

  // ---------- FAB ----------
  const fab = document.querySelector('.fab');
  const fabMain = document.querySelector('.fab-main');
  if (fab && fabMain){
    fabMain.addEventListener('click', e => { e.stopPropagation(); fab.classList.toggle('open'); });
    document.addEventListener('click', e => { if (!fab.contains(e.target)) fab.classList.remove('open'); });
  }

  // ---------- TOAST ----------
  const toast = document.getElementById('toast');
  function showToast(msg){
    if (!toast) return;
    toast.querySelector('.msg').textContent = msg;
    toast.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => toast.classList.remove('show'), 3600);
  }
  window.showToast = showToast;

  // ---------- CURRENT TIME in nav hours ----------
  function updateHours(){
    const el = document.getElementById('navTime');
    if (!el) return;
    const d = new Date();
    const hh = String(d.getHours()).padStart(2, '0');
    const mm = String(d.getMinutes()).padStart(2, '0');
    el.textContent = `${hh}:${mm}`;
  }
  updateHours();
  setInterval(updateHours, 30000);

})();
